<?php
namespace Tests\Feature;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\{User,Departamento,Cargo};
use Laravel\Sanctum\Sanctum;

class UsuarioTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

   public function test_index_returns_users(): void
    {
        $user = User::factory()->create(); // Crea un usuario para autenticación
        Sanctum::actingAs($user);          // Autentica el usuario
        $response = $this->getJson('/api/usuarios');
        $response->assertOk()->assertJsonStructure(['data']);
    }
    public function test_store_creates_user(): void
{
    $user = User::factory()->create();
    Sanctum::actingAs($user);

    $departamento = Departamento::factory()->create();
    $cargo = Cargo::factory()->create();

    $payload = [
        'usuario'        => 'nuevoUser',
        'primerNombre'   => 'Juan',
        'primerApellido' => 'Pérez',
        'email'          => 'nuevo@example.com',
        'password'       => 'secret123',
        'idDepartamento' => $departamento->id,
        'idCargo'        => $cargo->id,
    ];

    $response = $this->postJson('/api/usuarios', $payload);
    $response->assertCreated()->assertJsonPath('data.usuario', 'nuevoUser');
    $this->assertDatabaseHas('users', ['usuario' => 'nuevoUser']);
}

}