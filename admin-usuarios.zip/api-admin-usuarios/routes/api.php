<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{AuthController,UsuarioController,DepartamentoController,CargoController};

Route::prefix('auth')->group(function () {
    Route::post('/login',  [AuthController::class,'login']);
    Route::middleware('auth:sanctum')->post('/logout', [AuthController::class,'logout']);
});

Route::middleware('auth:sanctum')->group(function () {
    Route::apiResource('usuarios', UsuarioController::class);
    Route::get('departamentos', [DepartamentoController::class,'index']);
    Route::get('cargos',        [CargoController::class,'index']);
});