<?php
namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\ResourceCollection;
class UsuarioCollection extends ResourceCollection
{
    public $collects = UsuarioResource::class;

    public function toArray($request): array
    {
        return [
            'data' => $this->collection,

            'meta' => [
                'current_page' => $this->currentPage(),   // 1 ← escalar
                'last_page'    => $this->lastPage(),      // 2
                'per_page'     => $this->perPage(),       // 10 ← escalar
                'total'        => $this->total(),         // 13
                'from'         => $this->firstItem(),     // 1
                'to'           => $this->lastItem(),      // 10
            ],

            'links' => [
                'first' => $this->url(1),
                'last'  => $this->url($this->lastPage()),
                'prev'  => $this->previousPageUrl(),
                'next'  => $this->nextPageUrl(),
            ],
        ];
    }
}