<?php
namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;
class UsuarioResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id'        => $this->id,
            'usuario'   => $this->usuario,
            'nombres'   => trim($this->primerNombre.' '.$this->segundoNombre),
            'apellidos' => trim($this->primerApellido.' '.$this->segundoApellido),
            'telefono'  => $this->telefono,
            'email'     => $this->email,
            'departamento' => [
                'id'   => $this->departamento->id,
                'nombre' => $this->departamento->nombre,
            ],
            'cargo' => [
                'id'   => $this->cargo->id,
                'nombre' => $this->cargo->nombre,
            ],
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}