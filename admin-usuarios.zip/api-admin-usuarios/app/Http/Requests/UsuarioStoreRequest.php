<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
class UsuarioStoreRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'usuario'         => ['required','string','max:30','unique:users,usuario'],
            'primerNombre'    => ['required','string','max:60'],
            'segundoNombre'   => ['nullable','string','max:60'],
            'primerApellido'  => ['required','string','max:60'],
            'segundoApellido' => ['nullable','string','max:60'],
            'telefono'        => ['nullable','string','max:20'],
            'email'           => ['required','email','unique:users,email'],
            'password'        => ['required','string','min:8'],
            'idDepartamento'  => ['required','exists:departamentos,id'],
            'idCargo'         => ['required','exists:cargos,id'],
        ];
    }
}