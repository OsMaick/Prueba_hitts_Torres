<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
class UsuarioUpdateRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        $id = $this->route('usuario')->id;
        return [
            'usuario'         => ['sometimes','string','max:30','unique:users,usuario,'.$id],
            'primerNombre'    => ['sometimes','string','max:60'],
            'segundoNombre'   => ['sometimes','string','max:60'],
            'primerApellido'  => ['sometimes','string','max:60'],
            'segundoApellido' => ['sometimes','string','max:60'],
            'telefono'        => ['nullable','string','max:20'],
            'email'           => ['sometimes','email','unique:users,email,'.$id],
            'password'        => ['sometimes','string','min:8'],
            'idDepartamento'  => ['sometimes','exists:departamentos,id'],
            'idCargo'         => ['sometimes','exists:cargos,id'],
        ];
    }
}