<?php
namespace App\Http\Controllers;
use App\Models\User;
use App\Http\Requests\{UsuarioStoreRequest,UsuarioUpdateRequest};
use App\Http\Resources\{UsuarioResource,UsuarioCollection};
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request; 

class UsuarioController extends Controller
{
    public function __construct() { $this->middleware('auth:sanctum'); }

    public function index(Request $request): UsuarioCollection
    {
       $query = User::with(['departamento', 'cargo']);

    /* ───── filtro texto global ───── */
    if ($search = $request->input('search')) {
        $query->where(function ($q) use ($search) {
            $q->where('usuario', 'like', "%{$search}%")
              ->orWhere('nombres', 'like', "%{$search}%")
              ->orWhere('apellidos', 'like', "%{$search}%")
              ->orWhere('email', 'like', "%{$search}%");
        });
    }

    /* ───── filtro Departamento ───── */
    if ($request->filled('departamentoId')) {
        $query->where('idDepartamento', $request->departamentoId);
    }

    /* ───── filtro Cargo ───── */
    if ($request->filled('cargoId')) {
        $query->where('idCargo', $request->cargoId);
    }

    /* tamaño de página (por defecto 10) */
    $perPage = $request->input('per_page', 10);

    return new UsuarioCollection($query->paginate($perPage));
    }

    public function store(UsuarioStoreRequest $request): UsuarioResource
    {
    // Obtenemos los datos validados
        $data = $request->validated();

        // Sobrescribimos la clave 'password' con su versión hasheada
        $data['password'] = bcrypt($data['password']);
        

        // Creamos el usuario
        $user = User::create($data);

        //$user = User::create($request->validated());
        return new UsuarioResource($user->load(['departamento','cargo']));
    }

    public function show(User $usuario): UsuarioResource
    {
        return new UsuarioResource($usuario->load(['departamento','cargo']));
    }

    public function update(UsuarioUpdateRequest $request, User $usuario): UsuarioResource
    {
        $usuario->update($request->validated());
        return new UsuarioResource($usuario->refresh()->load(['departamento','cargo']));
    }

    public function destroy(User $usuario): JsonResponse
    {
        $usuario->delete();
        return response()->json(null, 204);
    }
}