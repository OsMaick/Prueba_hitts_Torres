<?php
namespace App\Http\Controllers;
use App\Models\Cargo;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use App\Http\Resources\CargoResource;
class CargoController extends Controller
{
    public function __construct() { $this->middleware('auth:sanctum'); }
    public function index(): AnonymousResourceCollection
    {
        return CargoResource::collection(Cargo::all());
    }
}