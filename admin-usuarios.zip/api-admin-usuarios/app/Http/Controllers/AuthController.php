<?php
namespace App\Http\Controllers;
use App\Http\Requests\LoginRequest;
use Illuminate\Http\{Request,JsonResponse};
use Illuminate\Support\Facades\Hash;
use App\Models\User;
class AuthController extends Controller
{
    public function login(LoginRequest $request): JsonResponse
    {
        /* ➊ ─ Usuario cuyo departamento sea el 1 (Administración) */
    $user = User::where('usuario', $request->usuario)
                ->where('idDepartamento', 1)   // 👈 solo admin
                ->first();

    /* ➋ ─ Validamos existencia + password */
    if (! $user || ! Hash::check($request->password, $user->password)) {
        return response()->json(['message' => 'Credenciales inválidas'], 401);
    }

    /* ➌ ─ Generamos token */
    $token = $user->createToken('api')->plainTextToken;

    return response()->json([
        'token' => $token,
        'user'  => $user
    ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Sesión cerrada']);
    }
}