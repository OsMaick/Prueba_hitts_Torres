<?php
namespace App\Http\Controllers;
use App\Models\Departamento;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use App\Http\Resources\DepartamentoResource;
class DepartamentoController extends Controller
{
    public function __construct() { $this->middleware('auth:sanctum'); }
    public function index(): AnonymousResourceCollection
    {
        return DepartamentoResource::collection(Departamento::all());
    }
}