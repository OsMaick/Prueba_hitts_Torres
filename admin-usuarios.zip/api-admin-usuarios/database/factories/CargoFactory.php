<?php
namespace Database\Factories;
use App\Models\Cargo;
use Illuminate\Database\Eloquent\Factories\Factory;
class CargoFactory extends Factory
{
    protected $model = Cargo::class;
    public function definition(): array
    {
        return [
            'codigo' => $this->faker->unique()->bothify('CAR-###'),
            'nombre' => $this->faker->jobTitle,
            'activo' => $this->faker->boolean(90),
            'idUsuarioCreacion' => null,
        ];
    }
}