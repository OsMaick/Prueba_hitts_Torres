<?php
namespace Database\Factories;
use App\Models\{User,Departamento,Cargo};
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;


class UserFactory extends Factory
{
    protected $model = User::class;
    public function definition()
{
    return [
        'usuario'        => $this->faker->unique()->userName(),
        'primerNombre'   => $this->faker->firstName(),
        'segundoNombre'  => $this->faker->optional()->firstName(),
        'primerApellido' => $this->faker->lastName(),
        'segundoApellido'=> $this->faker->optional()->lastName(),
        'telefono'       => $this->faker->phoneNumber(),
        'email'          => $this->faker->unique()->safeEmail(),
        'email_verified_at' => now(),
        'password'       => bcrypt('password'), // password por defecto
        'idDepartamento' => Departamento::factory(),  // Relación automática
        'idCargo'        => Cargo::factory(),
        'remember_token' => Str::random(10),
    ];
}
}