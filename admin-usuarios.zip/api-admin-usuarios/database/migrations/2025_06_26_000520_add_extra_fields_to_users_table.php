<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        // ─── Datos de identificación ───────────────────────────────
        $table->string('usuario', 30)->unique()->after('id');

        // ─── Nombres y apellidos ──────────────────────────────────
        $table->string('primerNombre', 60);
        $table->string('segundoNombre', 60)->nullable();
        $table->string('primerApellido', 60);
        $table->string('segundoApellido', 60)->nullable();

        // ─── Relaciones ───────────────────────────────────────────
        $table->foreignId('idDepartamento')
              ->constrained('departamentos')
              ->cascadeOnUpdate()
              ->onDelete('no action');

        $table->foreignId('idCargo')
              ->constrained('cargos')
              ->cascadeOnUpdate()
              ->onDelete('no action');

        // ─── Contacto ─────────────────────────────────────────────
        $table->string('telefono', 20)->nullable();
    });
}

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // En orden inverso para evitar restricciones de FK
            $table->dropForeign(['idCargo']);
            $table->dropForeign(['idDepartamento']);

            $table->dropColumn([
                'usuario',
                'primerNombre',
                'segundoNombre',
                'primerApellido',
                'segundoApellido',
                'idDepartamento',
                'idCargo',
                'telefono',
            ]);
        });
    }
};
