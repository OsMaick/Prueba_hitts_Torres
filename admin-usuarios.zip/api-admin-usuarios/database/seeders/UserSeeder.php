<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\{User,Departamento,Cargo};
class UserSeeder extends Seeder
{
   public function run(): void
    {
        $registros = [
            [
                'usuario'  => 'ppicapiedra',
                'nombres'  => 'Pedro',
                'apellidos'=> 'Picapiedra',
                'email'    => 'ppicapiedra@gmail.com',
                'departamento'=> 'Tecnología de la información',
                'cargo'        => 'Administrador',
            ],
            [
                'usuario'  => 'pmarmol',
                'nombres'  => 'Pablo',
                'apellidos'=> 'Marmol',
                'email'    => 'pmarmol@gmail.com',
                'departamento'=> 'Tecnología de la información',
                'cargo'        => 'Líder Frontend',
            ],
            [
                'usuario'  => 'jalimaña',
                'nombres'  => 'Juanito',
                'apellidos'=> 'Alimaña',
                'email'    => 'jalimaña@gmail.com',
                'departamento'=> 'Seguridad',
                'cargo'        => 'Guardia',
            ],
            [
                'usuario'  => 'jpinkman',
                'nombres'  => 'Jesse',
                'apellidos'=> 'Pinkman',
                'email'    => 'jpinkman@gmail.com',
                'departamento'=> 'Eventos y Buffers',
                'cargo'        => 'Desarrollador Frontend',
            ],
            [
                'usuario'  => 'sgoodman',
                'nombres'  => 'Saul',
                'apellidos'=> 'Goodman',
                'email'    => 'sgoodman@gmail.com',
                'departamento'=> 'Legal',
                'cargo'        => 'Abogado',
            ],
            [
                'usuario'  => 'kwexler',
                'nombres'  => 'Kimberly',
                'apellidos'=> 'Wexler',
                'email'    => 'kwexler@gmail.com',
                'departamento'=> 'Legal',
                'cargo'        => 'Abogado',
            ],
            [
                'usuario'  => 'gfring',
                'nombres'  => 'Gustavo',
                'apellidos'=> 'Fring',
                'email'    => 'gfring@gmail.com',
                'departamento'=> 'Seguridad',
                'cargo'        => 'Pollero',
            ],
        ];

        foreach ($registros as $row) {
            User::updateOrCreate(
                ['usuario' => $row['usuario']],
                [
                    'primerNombre'   => $row['nombres'],
                    'primerApellido' => $row['apellidos'],
                    'email'          => $row['email'],
                    'idDepartamento' => Departamento::where('nombre', $row['departamento'])->first()->id,
                    'idCargo'        => Cargo::where('nombre', $row['cargo'])->first()->id,
                    'password'       => bcrypt('password'),   // clave por defecto
                ]
            );
        }
    }
}