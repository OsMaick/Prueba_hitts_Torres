<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Cargo;
class CargoSeeder extends Seeder
{
    public function run(): void
    {
        $cargos = [
            'Administrador',
            'Líder Frontend',
            'Desarrollador Frontend',
            'Abogado',
            'Guardia',
            'Pollero',
        ];

        foreach ($cargos as $index => $nombre) {
            Cargo::updateOrCreate(
                ['codigo' => 'CAR-'.str_pad($index+1, 3, '0', STR_PAD_LEFT)],
                [
                    'nombre'            => $nombre,
                    'activo'            => 1,
                    'idUsuarioCreacion' => 1,
                ]
            );
        }
    }
}