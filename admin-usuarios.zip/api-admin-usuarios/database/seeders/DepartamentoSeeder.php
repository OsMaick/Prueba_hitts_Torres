<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Departamento;
class DepartamentoSeeder extends Seeder
{
    public function run(): void
    {
        $departamentos = [
            'Tecnología de la información',
            'Legal',
            'Seguridad',
            'Eventos y Buffers',
        ];

        foreach ($departamentos as $index => $nombre) {
            Departamento::updateOrCreate(
                ['codigo' => 'DEP-'.str_pad($index+1, 3, '0', STR_PAD_LEFT)],
                [
                    'nombre'            => $nombre,
                    'activo'            => 1,
                    'idUsuarioCreacion' => 1,   // o el ID de tu “admin”
                ]
            );
        }
    }
}