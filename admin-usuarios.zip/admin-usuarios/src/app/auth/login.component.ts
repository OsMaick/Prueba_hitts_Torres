import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [MatProgressSpinnerModule,CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `<form [formGroup]="form" (ngSubmit)="onSubmit()" class="login-form">
  <h2 class="login-title">Iniciar sesión</h2>

  <mat-form-field appearance="outline" class="full-width">
    <mat-label style="
    padding: 20px;
">Usuario</mat-label>
    <input matInput formControlName="usuario" required autocomplete="username" />
    <mat-icon matPrefix></mat-icon>
    <mat-error *ngIf="form.get('usuario')?.hasError('required')">
      El usuario es obligatorio
    </mat-error>
  </mat-form-field>

  <mat-form-field appearance="outline" class="full-width">
    <mat-label style="
    padding: 20px;
">Contraseña</mat-label>
    <input matInput type="password" formControlName="password" required autocomplete="current-password" />
    <mat-icon matPrefix></mat-icon>
    <mat-error *ngIf="form.get('password')?.hasError('required')">
      La contraseña es obligatoria
    </mat-error>
  </mat-form-field>
    <button mat-raised-button color="primary" type="submit" [disabled]="form.invalid || loading" class="btn-login">
    <mat-progress-spinner 
      *ngIf="loading" 
      mode="indeterminate" 
      diameter="20" 
      color="accent" 
      class="spinner-btn">
    </mat-progress-spinner>
    <span *ngIf="!loading">Entrar</span>
  </button>
</form>

  `,
  styles: [`
    .login-form {
  max-width: 360px;
  margin: 40px auto;
  padding: 24px 32px;
  background: #f5f9ff;
  border-radius: 8px;
  box-shadow: 0 4px 14px rgba(0, 117, 194, 0.2);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;

  .login-title {
    text-align: center;
    color: #004a99;
    margin-bottom: 24px;
    font-weight: 700;
  }

  .full-width {
    width: 100%;
    margin-bottom: 20px;

    .mat-form-field-outline {
      border-color: #0077c2 !important;
    }

    .mat-form-field-label {
      color: #0077c2 !important;
      font-weight: 600;
      
    }

    mat-icon {
      color: #004a99;
    }
  }

  .btn-login {
    width: 100%;
    padding: 12px 0;
    font-weight: 700;
    font-size: 1rem;
    background-color: #0077c2 !important;
    color: white !important;
    transition: background-color 0.3s ease;

    &:hover:not(:disabled) {
      background-color: #005a99 !important;
    }
  }
}
.spinner-btn {
  vertical-align: middle;
  margin-right: 8px;
  display: inline-block;
  background-color: #ffffff !important;
}

  `]
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);

  form = this.fb.group({
    usuario: ['', Validators.required],
    password: ['', Validators.required]
  });
  loading = false;
  onSubmit() {
    if (this.form.invalid) return;
    this.loading = true;
    const { usuario, password } = this.form.value;
    this.auth.login(usuario!, password!).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigate(['/admin-usuarios'])
        // redirigir o acciones luego del login
      },
      error: () => {
        this.loading = false;
        alert('Usuario o contraseña incorrectos')
      }
    });
  }
}
