import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = 'http://localhost:8000/api/auth'; // Cambia si tu backend usa otra ruta

  constructor(private http: HttpClient) {}

  login(usuario: string, password: string) {
    return this.http.post<{ token: string }>(`${this.api}/login`, { usuario, password })
      .pipe(tap(res => localStorage.setItem('token', res.token)));
  }

  logout() {
    localStorage.removeItem('token');
  }

  token(): string | null {
    return localStorage.getItem('token');
  }

  isLoggedIn(): boolean {
    return !!this.token();
  }
}
