import { Route } from '@angular/router';
import { LoginComponent } from './auth/login.component';
import { adminUsuariosRoutes } from './admin-usuarios/admin-usuarios.routes';
import { authGuard } from './auth/auth.guard';

export const routes: Route[] = [
  { path: 'login', component: LoginComponent },
  {
    path: 'admin-usuarios',
    canActivate: [authGuard],
    loadChildren: () => import('./admin-usuarios/admin-usuarios.routes').then(m => m.adminUsuariosRoutes)
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' }
];
