import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { map } from 'rxjs/operators';

export interface UsuarioDTO {
  id?: number;
  usuario?: string;
  nombres?: string;
  apellidos?: string;
  telefono?: string;
  email?: string;
  departamento?: { id: number; nombre: string };
  cargo?: { id: number; nombre: string };
  activo?: boolean;
}

@Injectable({ providedIn: 'root' })
export class Usuarios {
  //private readonly api = '/api';
  private readonly api = 'http://localhost:8000/api';

  // Signal para cache simple (Angular 20)
  usuarios = signal<UsuarioDTO[]>([]);

  constructor(private http: HttpClient) {}

  fetchUsuarios(
  page        = 1,
  perPage     = 10,                     // ← nuevo
  search      = '',
  departamentoId: string | number = '',
  cargoId: string | number = ''
): Observable<{ data: UsuarioDTO[]; meta: any }> {

  /* construimos los parámetros sólo si tienen valor ---------------- */
  let params = new HttpParams()
    .set('page',      page.toString())
    .set('per_page',  perPage.toString());

  if (search)          params = params.set('search', search);
  if (departamentoId)  params = params.set('departamentoId', departamentoId.toString());
  if (cargoId)         params = params.set('cargoId',        cargoId.toString());

  return this.http.get<{ data: UsuarioDTO[]; meta: any }>(`${this.api}/usuarios`, { params })
    .pipe(tap(res => this.usuarios.set(res.data)));
}

  create(u: Partial<UsuarioDTO>): Observable<UsuarioDTO> {
    return this.http.post<UsuarioDTO>(`${this.api}/usuarios`, u);
  }
  update(u: UsuarioDTO): Observable<UsuarioDTO> {
    return this.http.put<UsuarioDTO>(`${this.api}/usuarios/${u.id}`, u);
  }
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/usuarios/${id}`);
  }

  departamentos(): Observable<any[]> {
    return this.http
      .get<{ data: any[] }>(`${this.api}/departamentos`)
      .pipe(map(r => r.data));         // devuelve sólo el array
  }

  cargos(): Observable<any[]> {
    return this.http
      .get<{ data: any[] }>(`${this.api}/cargos`)
      .pipe(map(r => r.data));         // idem
  }
}