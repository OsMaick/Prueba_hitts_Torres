import { Component, ViewChild, signal, computed, inject, effect } from '@angular/core';
import {
  MatTableDataSource, MatTableModule
} from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { CommonModule } from '@angular/common';
import { Usuarios, UsuarioDTO } from '../services/usuarios';
import { UsuarioForm} from '../usuario-form/usuario-form';
import { ConfirmDialog } from '../confirm-dialog/confirm-dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { fromEvent } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { AuthService } from '../../auth/auth.service';
@Component({
  selector: 'app-usuarios-list',
  standalone: true,
  templateUrl: './usuarios-list.html',
  styleUrls: ['./usuarios-list.scss'],
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatIconModule,
    MatButtonModule,
    MatSlideToggleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatDialogModule
  ]
})
export class UsuariosList {
  page    = 1;          // página actual (API = base 1)
  perPage = 10;         // filas por página
  total   = 0; 
  private snack = inject(MatSnackBar);
  filtros = {
    departamentoId: '',
    cargoId: ''
  };
  private router = inject(Router);
  departamentos: any[] = [];
  cargos: any[] = [];

  private service = inject(Usuarios);
  private dialog  = inject(MatDialog);

  displayedColumns = [
  'usuario',
  'nombres',
  'apellidos',
  'departamento',
  'cargo',
  'email',
  'acciones'
];
  dataSource = new MatTableDataSource<UsuarioDTO>();

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor() {
    // Carga inicial
    this.service.fetchUsuarios();
    
    effect(() => {
      this.dataSource.data = this.service.usuarios();
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });

    this.service.departamentos().subscribe(arr => (this.departamentos = arr));
    this.service.cargos().subscribe(arr => (this.cargos = arr));

    /* 1ª carga de usuarios */
    this.loadPage();
  }

  /** Llama al backend con los filtros seleccionados */
filtrar() {
  // reinicia a la página 1 cada vez que cambies filtro
  this.paginator.firstPage?.();       // si existe paginator ya creado
  this.loadPage(1,10, this.globalSearch); // usa último término de búsqueda
}

/** globalSearch lo actualizas en applyFilter */
globalSearch = '';

applyFilter(term: string) {
  this.globalSearch = term.trim();
  this.loadPage(1,10, this.globalSearch);
}

  

  openForm(usuario?: UsuarioDTO) {
    this.dialog
      .open(UsuarioForm, { data: usuario })
      .afterClosed()
      .subscribe(() => this.service.fetchUsuarios());
  }

  confirmDelete(id: number): void {
  this.dialog.open(ConfirmDialog, {
      data: { text: '¿Eliminar este usuario?' }
    })
    .afterClosed()
    .subscribe(confirmed => {
      if (!confirmed) {
        return; // usuario canceló
      }

      this.service.delete(id).subscribe({
        next: () => {
          /* recargar lista */
          this.loadPage(1, 10, this.globalSearch);

          /* toast de éxito */
          this.snack.open('Usuario eliminado correctamente', 'Cerrar', {
            duration: 3000,            // 3 s
            panelClass: ['toast-success'] // clase CSS opcional
          });
        },
        error: () => {
          /* toast de error */
          this.snack.open('No se pudo eliminar', 'Cerrar', {
            duration: 3000,
            panelClass: ['toast-error']
          });
        }
      });
    });
}

  //@ViewChild(MatPaginator) paginator!: MatPaginator;

  ngAfterViewInit() {
    // Carga inicial
    this.loadPage();

    // Cambios de página → backend
    this.paginator.page.subscribe(event => {
      this.perPage = event.pageSize; // ← nuevo tamaño
      this.loadPage(event.pageIndex + 1);
      
    });

    }

  onPageChange(pe: PageEvent): void {
    this.page    = pe.pageIndex + 1; // Angular → base 0  → +1
    this.perPage = pe.pageSize;
    this.loadPage();
  }

  loadPage(page = 1, perPage = 10,search = '') {
  this.service.fetchUsuarios(
    this.page,
    this.perPage,
    search,
    this.filtros.departamentoId,
    this.filtros.cargoId
  )
  .subscribe({
    next: res => {
      this.total = res.meta.total;            // ← ahora es un número
      
    },
    error: () => this.router.navigate(['/login'])
  });

   
}
 private auth   = inject(AuthService);
  logout(): void {
    this.auth.logout();            // borra token
    this.router.navigate(['/login']);
  }
  
}