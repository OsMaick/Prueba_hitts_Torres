import { Routes } from '@angular/router';
import { authGuard } from '../admin-usuarios/guards/auth-guard';
import { UsuariosList } from './usuarios-list/usuarios-list';

export const adminUsuariosRoutes: Routes = [
  {
    path: '',
    component: UsuariosList,
    canActivate: [authGuard]
    // Puedes agregar guards aquí (ejemplo: canActivate: [AuthGuard])
  }
];
