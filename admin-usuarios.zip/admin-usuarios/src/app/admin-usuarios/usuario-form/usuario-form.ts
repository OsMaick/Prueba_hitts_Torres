import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Usuarios, UsuarioDTO } from '../services/usuarios';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatOptionModule } from '@angular/material/core';
import { MatSnackBar }     from '@angular/material/snack-bar';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-usuario-form',
  standalone: true,
  templateUrl: './usuario-form.html',
  styleUrls: ['./usuario-form.scss'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatSlideToggleModule,
    MatOptionModule
  ]
})
export class UsuarioForm implements OnInit {
  form!: FormGroup;
  departamentos: any[] = [];
  cargos: any[] = [];
  private snack = Inject(MatSnackBar);

  constructor(
    private fb: FormBuilder,
    public service: Usuarios,
    public dialog: MatDialogRef<UsuarioForm>,
    @Inject(MAT_DIALOG_DATA) public data: UsuarioDTO | null
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      usuario:        ['', Validators.required],
      primerNombre:   ['', Validators.required],
      segundoNombre:  [''],
      primerApellido: ['', Validators.required],
      segundoApellido:[''],
      email:          ['', [Validators.required, Validators.email]],
      password:       ['password', null],
      idDepartamento: [null, Validators.required],
      idCargo:        [null, Validators.required],
      //activo:         [true]
    });

      this.service.departamentos().subscribe(arr => {
        console.log('departamentos ➜', arr);
        this.departamentos = arr;
      });

      this.service.cargos().subscribe(arr => {
        console.log('cargos ➜', arr);
        this.cargos = arr;
      });

      if (this.data) {
        // --- Nombres ---
        const [primerNombre, ...restN] = (this.data.nombres ?? '').trim().split(' ');
        const segundoNombre            = restN.join(' ');  // puede quedar vacío

        // --- Apellidos ---
        const [primerApellido, ...restA] = (this.data.apellidos ?? '').trim().split(' ');
        const segundoApellido             = restA.join(' ');
      this.form.patchValue({
        usuario:         this.data.usuario,
        email:           this.data.email,

        primerNombre,
        segundoNombre,
        primerApellido,
        segundoApellido,

        idDepartamento: this.data.departamento?.id,
        idCargo: this.data.cargo?.id
      });
    }
  }

  save(): void {
    if (this.form.invalid) return;

    const raw = this.form.getRawValue();

    const payload: Partial<UsuarioDTO> = {
      ...raw,
      departamento: { id: raw.idDepartamento!, nombre: '' },
      cargo: { id: raw.idCargo!, nombre: '' }
    };

    const obs$ = this.data?.id
      ? this.service.update({ ...payload, id: this.data.id })
      : this.service.create(payload);

    obs$.subscribe({
      next: () => this.dialog.close(true),
      error: (err: HttpErrorResponse) => this.handleServerError(err)
    });
    
  }
  private handleServerError(error: HttpErrorResponse) {
    if (error.status === 422 && error.error?.errors) {
      const errors = error.error.errors;
      // Itera las claves (usuario, email, etc.)
      Object.keys(errors).forEach(field => {
        const control = this.form.get(field);
        if (control) {
          // setErrors MANTIENE errores previos + agrega 'server'
          control.setErrors({ server: errors[field][0] });
        }
      });
    }

    // Snack global opcional
    this.snack.open(error.error?.message || 'Error al guardar', 'Cerrar', {
      duration: 4000,
      panelClass: 'snack-error'
    });
  }
}
